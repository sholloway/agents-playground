from typing import Callable, Dict, Final

TASKS_REGISTRY: Final[Dict[str,Callable]] = {
  # 'agent_pacing': am.agent_pacing,
  # 'agents_spinning' : am.agents_spinning,
  # 'agent_random_navigation' : am.agent_random_navigation,
  # 'generate_agents': ga.generate_agents
}