from typing import Union

Tag = Union[int, float, str, None]