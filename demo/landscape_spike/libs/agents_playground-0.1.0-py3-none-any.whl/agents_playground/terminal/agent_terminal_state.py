from enum import auto, Enum

class AgentTerminalMode(Enum):
  COMMAND = auto()
  INSERT  = auto()