from agents_playground.app.main import main

main()